#include "../../Service/Std_type.h"
#include "../../Service/bit_math.h"
#include "../../Service/reg.h"
#include "TIMER0_int.h"
#include "TIMER0_cfg.h"
#include <avr/interrupt.h>
#include <util/delay.h>

#define MAX_TIMER_CALLBACKS  3

static void (*timer0_callbacks[MAX_TIMER_CALLBACKS])(void) = {NULL};
static void (*TIMER0_OV_CALL_BACK)(void) = NULL;
static void (*TIMER0_OC_CALL_BACK)(void) = NULL;
volatile u32 systemTickCount = 0;
extern volatile u32 systemTickCount;

#define TIMER0_PRELOAD 6

void TIMER0_voidInit(void) {
    TIMER0_TCCR0_REG = 0;

    #if TIMER0_PRESCALAR == TIMER0_1024_PRESCALAR
        SET_BIT(TIMER0_TCCR0_REG, CS02);
        SET_BIT(TIMER0_TCCR0_REG, CS00);
    #endif

    #if TIMER0_MODE == TIMER0_CTC
        SET_BIT(TIMER0_TCCR0_REG, WGM01);
    #endif

    TIMER0_TCNT0_REG = TIMER0_INITIAL_PRELOAD;
    TIMER0_OCR0_REG = TIMER0_INITIAL_OCR_VAL;
}

void TIMER0_voidStart(void)
{
    TIMER0_TCCR0_REG |= (TIMER0_PRESCALAR & 0x07);
}

void TIMER0_voidStop(void)
{
    TIMER0_TCCR0_REG &= 0xF8;
}

TIMER0_Error_t TIMER0_voidSetPreLoadVal(u8 Copy_u8Val)
{
    TIMER0_TCNT0_REG = Copy_u8Val;
    return TIMER0_OK;
}

TIMER0_Error_t TIMER0_voidSetOCVal(u8 Copy_u8Val)  // Fixed return type
{
    if(Copy_u8Val > 255) return TIMER0_INVALID_DUTY;
    TIMER0_OCR0_REG = Copy_u8Val;
    return TIMER0_OK;
}

TIMER0_Error_t TIMER0_voidSetPWM(u8 Copy_u8DutyCycle, u8 Copy_u8Mode)
{
    if(Copy_u8DutyCycle > 100) return TIMER0_INVALID_DUTY;

    if(Copy_u8Mode == TIMER0_NON_INVERTED) {
        CLR_BIT(TIMER0_TCCR0_REG, TIMER0_TCCR0_COM00);
        SET_BIT(TIMER0_TCCR0_REG, TIMER0_TCCR0_COM01);
    }
    else if(Copy_u8Mode == TIMER0_INVERTED) {
        SET_BIT(TIMER0_TCCR0_REG, TIMER0_TCCR0_COM00);
        SET_BIT(TIMER0_TCCR0_REG, TIMER0_TCCR0_COM01);
    }
    else {
        return TIMER0_INVALID_MODE;
    }

    TIMER0_OCR0_REG = (Copy_u8DutyCycle * 255) / 100;
    return TIMER0_OK;
}

TIMER0_Error_t TIMER0_voidSet_OV_CallBack(void (*pf)(void))
{
	if(pf == NULL) return TIMER0_CALLBACK_NULL;

	    for(u8 i=0; i<MAX_TIMER_CALLBACKS; i++) {
	        if(timer0_callbacks[i] == NULL) {
	            timer0_callbacks[i] = pf;
	            SET_BIT(TIMER0_TIMSK_REG, TIMER0_TIMSK_TOIE0);
	            return TIMER0_OK;
	        }
	    }
	    return TIMER0_CALLBACK_FULL;
}

TIMER0_Error_t TIMER0_voidSet_OC_CallBack(void (*pf)(void))
{
    if(pf == NULL) return TIMER0_CALLBACK_NULL;

    TIMER0_OC_CALL_BACK = pf;
    SET_BIT(TIMER0_TIMSK_REG, TIMER0_TIMSK_OCIE0);
    return TIMER0_OK;
}

#define MAX_CALLBACKS 3
static void (*callbacks[MAX_CALLBACKS])(void) = {NULL};

void TIMER0_voidAddCallback(void (*func)(void)) {
    for(u8 i=0; i<MAX_CALLBACKS; i++) {
        if(!callbacks[i]) {
            callbacks[i] = func;
            break;
        }
    }
}

ISR(TIMER0_OVF_vect) {
    systemTickCount++;
    for(u8 i=0; i<MAX_CALLBACKS; i++) {
        if(timer0_callbacks[i] != NULL) {
            timer0_callbacks[i]();
        }
    }
}
