#ifndef MCAL_TIMER0_TIMER0_INT_H_
#define MCAL_TIMER0_TIMER0_INT_H_

#include "../../Service/Std_type.h"

#define TIMER0_DISABLED        0
#define TIMER0_NO_PRESCALAR    1
#define TIMER0_8_PRESCALAR     2
#define TIMER0_64_PRESCALAR    3
#define TIMER0_256_PRESCALAR   4
#define TIMER0_1024_PRESCALAR  5
#define TIMER0_EXT_FALLING     6
#define TIMER0_EXT_RISING      7

#define TIMER0_NORMAL          0
#define TIMER0_PWM             1
#define TIMER0_CTC             2
#define TIMER0_FAST_PWM        3

#define TIMER0_INVERTED        0
#define TIMER0_NON_INVERTED    1

#define TIMER0_MS_TO_TICKS(ms, prescaler) ((F_CPU/1000)*(ms)/(prescaler))
#define TIMER0_US_TO_TICKS(us, prescaler) ((F_CPU/1000000)*(us)/(prescaler))

typedef enum {
    TIMER0_OK,
    TIMER0_INVALID_MODE,
    TIMER0_INVALID_DUTY,
	 TIMER0_CALLBACK_FULL,
    TIMER0_CALLBACK_NULL,
	TIMER0_INVALID_STATE
} TIMER0_Error_t;

typedef enum {
    TIMER0_STOPPED,
    TIMER0_RUNNING,
    TIMER0_PAUSED
} TIMER0_State_t;

void TIMER0_voidInit(void);
TIMER0_Error_t TIMER0_voidSetPreLoadVal(u8 Copy_u8Val);
TIMER0_Error_t TIMER0_voidSet_OV_CallBack(void (*callback)(void));
TIMER0_Error_t TIMER0_voidSet_OC_CallBack(void (*callback)(void));
TIMER0_Error_t TIMER0_voidSetPWM(u8 Copy_u8DutyCycle, u8 Copy_u8Mode);
TIMER0_Error_t TIMER0_voidSetOCVal(u8 Copy_u8Val);
void TIMER0_voidStart(void);
void TIMER0_voidStop(void);
extern volatile u32 ticks;
extern volatile u32 systemTickCount;

#endif
