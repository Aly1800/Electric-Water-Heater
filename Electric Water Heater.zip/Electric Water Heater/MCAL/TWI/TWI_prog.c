#include "../../Service/Std_type.h"
#include "../../Service/bit_math.h"
#include "../../Service/reg.h"
#include "TWI_int.h"

#define TWI_TIMEOUT_VALUE 10000  // Adjust based on clock speed

static u8 TWI_u8CheckTimeout(void) {
    static u32 timeout = 0;
    if(++timeout > TWI_TIMEOUT_VALUE) {
        timeout = 0;
        return 1;
    }
    return 0;
}

void TWI_voidInitMaster(){
    TWI_BIT_RATE_REG = 12;
    CLR_BIT(TWI_CTRL_REG, TWI_CTRL_TWEA);
    SET_BIT(TWI_CTRL_REG, TWI_CTRL_TWEN);
}

void TWI_voidInitSlave( u8 Copy_u8SlaveAddress){

	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWEA);

	TWI_ADDRESS_REG = Copy_u8SlaveAddress << 1   ;

	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWEN);
}

s8 TWI_s8SendStartCondition(void) {
    TWI_CTRL_REG = (1 << TWI_CTRL_TWINT) |
                   (1 << TWI_CTRL_TWSTA) |
                   (1 << TWI_CTRL_TWEN);
    u32 timeout = 0;
    while (!GET_BIT(TWI_CTRL_REG, TWI_CTRL_TWINT)) {
        if (++timeout > TWI_TIMEOUT_VALUE) {
            return TWI_TIMEOUT;
        }
    }
    u8 status = TWI_STATUS_REG & 0xF8;
    if (status != TWI_START_SENT &&
        status != TWI_REP_START_SENT) {
        return TWI_START_FAILED;
    }
    return TWI_OK;
}

s8 TWI_s8SendRepeatedStartCondition(){
	s8 Local_s8Error = 0 ;
	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWSTA);
	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT);

	while (GET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT) == 0 )
	{

	}
	if ((TWI_STATUS_REG & 0xF8) != 0x10)
	{
		Local_s8Error = -1 ;
	}else {

	}
	return Local_s8Error;

}

s8 TWI_s8SendSlaveAddressWithWrite(u8 Copy_u8SlaveAddress){
	s8 Local_s8Error = 0 ;
	TWI_Data_REG = Copy_u8SlaveAddress << 1 ;
	CLR_BIT(TWI_Data_REG, 0);
	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT);

	while (GET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT) == 0 )
	{

	}
	if ((TWI_STATUS_REG & 0xF8) != 0x18)
	{
		Local_s8Error = -1 ;
	}else {

	}
	return Local_s8Error;

}

s8 TWI_s8SendSlaveAddressWithRead(u8 Copy_u8SlaveAddress){
	s8 Local_s8Error = 0 ;

	TWI_Data_REG = Copy_u8SlaveAddress << 1 ;
	SET_BIT(TWI_Data_REG, 0);
	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT);

	while (GET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT) == 0 )
	{

	}

	if ((TWI_STATUS_REG & 0xF8) != 0x40)
	{
		Local_s8Error = -1 ;
	}else {

	}
	return Local_s8Error;

}

s8 TWI_s8MasterWriteData(u8 Copy_s8DataToSend){
	s8 Local_s8Error = 0 ;

	TWI_Data_REG =Copy_s8DataToSend ;
	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT);

	while (GET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT) == 0 )
	{

	}
	if ((TWI_STATUS_REG & 0xF8) != 0x28)
	{
		Local_s8Error = -1 ;
	}else {

	}
	return Local_s8Error;
}

s8 TWI_s8MasterReadData (u8 * Copy_s8DataToSend){
	s8 Local_s8Error = 0 ;

	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT);

	while (GET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT) == 0 )
	{

	}

	if ((TWI_STATUS_REG & 0xF8) != 0x50)
	{
		Local_s8Error = -1 ;
	}else {
		*Copy_s8DataToSend = TWI_Data_REG ;
	}
	return Local_s8Error;
}

void TWI_voidSendStopCondition(){
	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWSTO);
	SET_BIT(TWI_CTRL_REG,TWI_CTRL_TWINT);
}
