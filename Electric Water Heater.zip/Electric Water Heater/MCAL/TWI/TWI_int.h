#ifndef MCAL_TWI_TWI_INT_H_
#define MCAL_TWI_TWI_INT_H_

typedef enum {
    TWI_START_SENT          = 0x08,
    TWI_REP_START_SENT      = 0x10,
    TWI_SLA_W_ACK           = 0x18,
    TWI_SLA_R_ACK           = 0x40,
    TWI_DATA_SENT_ACK       = 0x28,
    TWI_DATA_RECEIVED_ACK   = 0x50,
    TWI_ERROR_BUS_ERROR     = 0x00,
    TWI_ERROR_TIMEOUT       = 0xF0
} TWI_Status_t;

typedef enum {
    TWI_OK,
    TWI_BUS_ERROR,
    TWI_ARB_LOST,
    TWI_NACK_RECEIVED,
    TWI_TIMEOUT,
    TWI_INVALID_STATE,
    TWI_START_FAILED,
    TWI_REP_START_FAILED,
    TWI_ADDR_WRITE_FAILED,
    TWI_ADDR_READ_FAILED,
    TWI_DATA_WRITE_FAILED,
    TWI_DATA_READ_FAILED
} TWI_Error_t;

void TWI_voidInitMaster();
void TWI_voidInitSlave( u8 Copy_u8SlaveAddress);
s8 TWI_s8SendStartCondition(void);
s8 TWI_s8SendRepeatedStartCondition();
s8 TWI_s8SendSlaveAddressWithWrite(u8 Copy_u8SlaveAddress);
s8 TWI_s8SendSlaveAddressWithRead(u8 Copy_u8SlaveAddress);
s8 TWI_s8MasterWriteData(u8 Copy_u8DataToSend);
s8 TWI_s8MasterReadData (u8 * Copy_u8DataToSend);
s8 TWI_s8SlaveWriteData(u8 Copy_u8DataToSend);
s8 TWI_s8SlaveReadData (u8 * Copy_u8DataToSend);
void TWI_voidSendStopCondition();
static u8 TWI_u8CheckTimeout(void);

#endif
