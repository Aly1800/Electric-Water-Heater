#include "../../MCAL/DIO/DIO_int.h"
#include "../../MCAL/TIMER0/TIMER0_int.h"
#include "Element_int.h"

#define HEATER_PIN          DIO_PIN_0
#define PELTIER_PIN         DIO_PIN_1
#define STATUS_LED_PIN      DIO_PIN_2
#define HEATER_PWM_CHANNEL  TIMER0_OCA
#define PELTIER_PWM_CHANNEL TIMER0_OCB
#define MAX_PWM_DUTY        255

/* Timing Constants */
#define BLINK_BASE_PERIOD   20
/* State Variables */
static u8 safetyLockEnabled = 0;
static Element_State_t currentStates[3];
static u8 heaterPwmDuty = 0;
static u8 peltierPwmDuty = 0;
static u8 blinkPhase = 0;

void ELEMENT_Init(void) {
    /* Configure pins as outputs */
    DIO_voidSetPinDirection(DIO_PORTB, HEATER_PIN, DIO_PIN_OUTPUT);
    DIO_voidSetPinDirection(DIO_PORTB, PELTIER_PIN, DIO_PIN_OUTPUT);
    DIO_voidSetPinDirection(DIO_PORTB, STATUS_LED_PIN, DIO_PIN_OUTPUT);

    /* Initialize all elements to OFF state */
    currentStates[ELEMENT_HEATER] = ELEMENT_OFF;
    currentStates[ELEMENT_PELTIER] = ELEMENT_OFF;
    currentStates[ELEMENT_STATUS_LED] = ELEMENT_OFF;

    /* Initialize hardware states */
    DIO_voidSetPinValue(DIO_PORTB, HEATER_PIN, DIO_PIN_LOW);
    DIO_voidSetPinValue(DIO_PORTB, PELTIER_PIN, DIO_PIN_LOW);
    DIO_voidSetPinValue(DIO_PORTB, STATUS_LED_PIN, DIO_PIN_LOW);

    /* Initialize PWM if available */
    #ifdef USE_PWM_CONTROL
    TIMER0_voidInit();
    TIMER0_voidSetPWM(HEATER_PWM_CHANNEL, 0);
    TIMER0_voidSetPWM(PELTIER_PWM_CHANNEL, 0);
    #endif
}

Element_Error_t ELEMENT_SetState(Element_t element, Element_State_t state) {
    if(element > ELEMENT_STATUS_LED) return ELEMENT_INVALID_TYPE;

    if(safetyLockEnabled && element != ELEMENT_STATUS_LED && state != ELEMENT_OFF) {
        return ELEMENT_SAFETY_LOCK;
    }

    currentStates[element] = state;

    switch(element) {
        case ELEMENT_HEATER:
            if(state == ELEMENT_ON) {
                heaterPwmDuty = MAX_PWM_DUTY;
                #ifdef USE_PWM_CONTROL
                TIMER0_voidSetPWM(HEATER_PWM_CHANNEL, MAX_PWM_DUTY);
                #else
                DIO_voidSetPinValue(DIO_PORTB, HEATER_PIN, DIO_PIN_HIGH);
                #endif
            } else {
                heaterPwmDuty = 0;
                #ifdef USE_PWM_CONTROL
                TIMER0_voidSetPWM(HEATER_PWM_CHANNEL, 0);
                #endif
                DIO_voidSetPinValue(DIO_PORTB, HEATER_PIN, DIO_PIN_LOW);
            }
            break;

        /*case ELEMENT_PELTIER:
            if(state == ELEMENT_ON) {
                peltierPwmDuty = MAX_PWM_DUTY;
                #ifdef USE_PWM_CONTROL
                TIMER0_voidSetPWM(PELTIER_PWM_CHANNEL, MAX_PWM_DUTY);
                #else
                DIO_voidSetPinValue(DIO_PORTB, PELTIER_PIN, DIO_PIN_HIGH);
                #endif
            } else {
                peltierPwmDuty = 0;
                #ifdef USE_PWM_CONTROL
                TIMER0_voidSetPWM(PELTIER_PWM_CHANNEL, 0);
                #endif
                DIO_voidSetPinValue(DIO_PORTB, PELTIER_PIN, DIO_PIN_LOW);
            }
            break;*/

        case ELEMENT_STATUS_LED:
            break;
    }

    return ELEMENT_OK;
}

Element_Error_t ELEMENT_SetPwmDuty(Element_t element, u8 duty) {
    if(element > ELEMENT_PELTIER) return ELEMENT_INVALID_TYPE;
    if(duty > MAX_PWM_DUTY) return ELEMENT_INVALID_VALUE;
    if(safetyLockEnabled) return ELEMENT_SAFETY_LOCK;

    switch(element) {
        case ELEMENT_HEATER:
            heaterPwmDuty = duty;
            currentStates[ELEMENT_HEATER] = (duty > 0) ? ELEMENT_ON : ELEMENT_OFF;
            #ifdef USE_PWM_CONTROL
            TIMER0_voidSetPWM(HEATER_PWM_CHANNEL, duty);
            #else
            DIO_voidSetPinValue(DIO_PORTB, HEATER_PIN, (duty > 128) ? DIO_PIN_HIGH : DIO_PIN_LOW);
            #endif
            break;

        case ELEMENT_PELTIER:
            peltierPwmDuty = duty;
            currentStates[ELEMENT_PELTIER] = (duty > 0) ? ELEMENT_ON : ELEMENT_OFF;
            #ifdef USE_PWM_CONTROL
            TIMER0_voidSetPWM(PELTIER_PWM_CHANNEL, duty);
            #else
            DIO_voidSetPinValue(DIO_PORTB, PELTIER_PIN, (duty > 128) ? DIO_PIN_HIGH : DIO_PIN_LOW);
            #endif
            break;

        default:
            return ELEMENT_INVALID_TYPE;
    }

    return ELEMENT_OK;
}

Element_State_t ELEMENT_GetState(Element_t element) {
    if(element > ELEMENT_STATUS_LED) return ELEMENT_OFF;
    return currentStates[element];
}

u8 ELEMENT_GetPwmDuty(Element_t element) {
    switch(element) {
        case ELEMENT_HEATER: return heaterPwmDuty;
        case ELEMENT_PELTIER: return peltierPwmDuty;
        default: return 0;
    }
}

u8 ELEMENT_IsActive(Element_t element) {
    Element_State_t state = ELEMENT_GetState(element);
    return (state == ELEMENT_ON || state == ELEMENT_BLINK_SLOW || state == ELEMENT_BLINK_FAST);
}

void ELEMENT_EnableSafetyLock(u8 enable) {
    safetyLockEnabled = enable;
    if(enable) ELEMENT_ForceShutdown();
}

void ELEMENT_ForceShutdown(void) {
    /* Immediate hardware shutdown */
    DIO_voidSetPinValue(DIO_PORTB, HEATER_PIN, DIO_PIN_LOW);
    DIO_voidSetPinValue(DIO_PORTB, PELTIER_PIN, DIO_PIN_LOW);

    /* Stop PWM signals if enabled */
    #ifdef USE_PWM_CONTROL
    TIMER0_voidSetPWM(HEATER_PWM_CHANNEL, 0);
    TIMER0_voidSetPWM(PELTIER_PWM_CHANNEL, 0);
    #endif

    /* Update states */
    currentStates[ELEMENT_HEATER] = ELEMENT_OFF;
    currentStates[ELEMENT_PELTIER] = ELEMENT_OFF;
    heaterPwmDuty = 0;
    peltierPwmDuty = 0;

    /* Set error indicator */
    ELEMENT_SetState(ELEMENT_STATUS_LED, ELEMENT_BLINK_FAST);
}

void ELEMENT_Update(void) {
    /* Update blink phase (20ms increments) */
    blinkPhase = (blinkPhase + 1) % (BLINK_BASE_PERIOD * 2);

    /* Handle status LED */
    switch(currentStates[ELEMENT_STATUS_LED]) {
        case ELEMENT_BLINK_SLOW:  // 1Hz (500ms on/off)
            if(blinkPhase == 0) DIO_voidSetPinValue(DIO_PORTB, STATUS_LED_PIN, DIO_PIN_HIGH);
            if(blinkPhase == BLINK_BASE_PERIOD) DIO_voidSetPinValue(DIO_PORTB, STATUS_LED_PIN, DIO_PIN_LOW);
            break;

        case ELEMENT_BLINK_FAST:  // 2Hz (250ms on/off)
            if(blinkPhase % (BLINK_BASE_PERIOD/2) == 0) {
                DIO_voidTogPinValue(DIO_PORTB, STATUS_LED_PIN);
            }
            break;

        case ELEMENT_ON:
            DIO_voidSetPinValue(DIO_PORTB, STATUS_LED_PIN, DIO_PIN_HIGH);
            break;

        case ELEMENT_OFF:
            DIO_voidSetPinValue(DIO_PORTB, STATUS_LED_PIN, DIO_PIN_LOW);
            break;
    }
}

void ELEMENT_UpdateHeaterIndicator(u8 heatingActive, u8 coolingActive) {
    if(coolingActive) {
        ELEMENT_SetState(ELEMENT_STATUS_LED, ELEMENT_ON);
    }
    else if(heatingActive) {
        ELEMENT_SetState(ELEMENT_STATUS_LED, ELEMENT_BLINK_SLOW);
    }
    else {
        ELEMENT_SetState(ELEMENT_STATUS_LED, ELEMENT_OFF);
    }
}
