#ifndef ELEMENT_INTERFACE_H
#define ELEMENT_INTERFACE_H

#include "../../Service/Std_type.h"

typedef enum {
    ELEMENT_HEATER,
    ELEMENT_PELTIER,
    ELEMENT_STATUS_LED
} Element_t;

typedef enum {
    ELEMENT_OFF,
    ELEMENT_ON,
    ELEMENT_BLINK_SLOW,
    ELEMENT_BLINK_FAST
} Element_State_t;

typedef enum {
    ELEMENT_OK,
    ELEMENT_INVALID_TYPE,
    ELEMENT_SAFETY_LOCK,
    ELEMENT_INVALID_VALUE,
    ELEMENT_HARDWARE_ERROR
} Element_Error_t;

void ELEMENT_Init(void);
Element_Error_t ELEMENT_SetState(Element_t element, Element_State_t state);
Element_State_t ELEMENT_GetState(Element_t element);
Element_Error_t ELEMENT_SetPwmDuty(Element_t element, u8 duty);
u8 ELEMENT_GetPwmDuty(Element_t element);
u8 ELEMENT_IsActive(Element_t element);
void ELEMENT_EnableSafetyLock(u8 enable);
void ELEMENT_ForceShutdown(void);
void ELEMENT_Update(void);  // Call regularly (e.g. every 20ms)
void ELEMENT_UpdateHeaterIndicator(u8 heatingActive, u8 coolingActive);

#endif
