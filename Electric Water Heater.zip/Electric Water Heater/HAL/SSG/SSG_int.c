#include "SSG_int.h"
#include "../../MCAL/DIO/DIO_int.h"
#include "../../Service/reg.h"
#include "../../Service/bit_math.h"
#include <util/delay.h>

/* Segment patterns: bit 0 = A, bit 6 = G, bit 7 = DP */
static const u8 SEGMENT_PATTERNS[12] = {
    0b00111111, // 0
    0b00000110, // 1
    0b01011011, // 2
    0b01001111, // 3
    0b01100110, // 4
    0b01101101, // 5
    0b01111101, // 6
    0b00000111, // 7
    0b01111111, // 8
    0b01101111, // 9
    0b00000000, // blank
    0b10000000  // decimal point only
};

typedef struct {
    SSG_Config_t* config;
    u16 blinkCounter;
    u8 blinkState;
    u16 blinkInterval;
    u8 currentValue;
} DisplayState_t;

static DisplayState_t displayStates[2] = {{0}};
static u8 refreshCounter = 0;
static u8 currentActiveDigit = 0;

SSG_Error_t SSG_Init(SSG_Config_t* config) {
    if (!config) return SSG_INVALID_CONFIG;

    DIO_voidSetPortDirection(config->segmentPort, DIO_PORT_OUTPUT);
    DIO_voidSetPinDirection(config->enablePort, config->enablePin, DIO_PIN_OUTPUT);
    SSG_ClearDigit(config);
    SSG_DisableDigit(config);
    for (u8 i = 0; i < 2; i++) {
            if (displayStates[i].config == NULL) {
                displayStates[i].config = config;
                break;
            }
        }
    currentActiveDigit = 0;
    return SSG_OK;
}

void SSG_EnableDigit(SSG_Config_t* config) {
    if (!config) return;
    DIO_voidSetPinValue(config->enablePort, config->enablePin,
        config->activeLow ? DIO_PIN_LOW : DIO_PIN_HIGH);
}

void SSG_DisableDigit(SSG_Config_t* config) {
    if (!config) return;
    DIO_voidSetPinValue(config->enablePort, config->enablePin,
        config->activeLow ? DIO_PIN_HIGH : DIO_PIN_LOW);
}

void SSG_ClearDigit(SSG_Config_t* config) {
    if (!config) return;
    DIO_voidSetPortValue(config->segmentPort,
        (config->type == SSG_COMMON_CATHODE) ? 0x00 : 0xFF);
}

SSG_Error_t SSG_DisplayNumber(SSG_Config_t* config, u8 number) {
    if (!config) return SSG_INVALID_CONFIG;
    if (number > 11) return SSG_INVALID_NUMBER;

    u8 pattern = SEGMENT_PATTERNS[number];
    if (config->type == SSG_COMMON_ANODE) pattern = ~pattern;
    DIO_voidSetPortValue(config->segmentPort, pattern);
    return SSG_OK;
}

SSG_Error_t SSG_BlinkDigit(SSG_Config_t* config, u8 state, u16 blinkPeriodMs) {
    for (u8 i = 0; i < 2; i++) {
        if (displayStates[i].config == config || displayStates[i].config == NULL) {
            displayStates[i].config = config;
            displayStates[i].blinkState = state;
            displayStates[i].blinkInterval = blinkPeriodMs / 20;
            displayStates[i].blinkCounter = 0;
            return SSG_OK;
        }
    }
    return SSG_BLINK_ACTIVE;
}

SSG_Error_t SSG_DisplayTemperature(SSG_Config_t* digit1, SSG_Config_t* digit2, u8 temperature) {
    if (temperature > 99) return SSG_INVALID_NUMBER;
    if (digit1) displayStates[0].config = digit1, displayStates[0].currentValue = temperature / 10;
    if (digit2) displayStates[1].config = digit2, displayStates[1].currentValue = temperature % 10;
    return SSG_OK;
}

void SSG_UpdateDisplays(void) {
    for (u8 i = 0; i < 2; i++)
        if (displayStates[i].config) SSG_DisableDigit(displayStates[i].config);

    for (u8 i = 0; i < 2; i++) {
        if (displayStates[i].config && displayStates[i].blinkState) {
            if (++displayStates[i].blinkCounter >= displayStates[i].blinkInterval) {
                displayStates[i].blinkCounter = 0;
                DIO_voidTogPinValue(displayStates[i].config->enablePort,
                                    displayStates[i].config->enablePin);
            }
        }
    }

    if (displayStates[currentActiveDigit].config) {
        SSG_DisplayNumber(displayStates[currentActiveDigit].config,
                          displayStates[currentActiveDigit].currentValue);
        SSG_EnableDigit(displayStates[currentActiveDigit].config);
    }

    currentActiveDigit = (currentActiveDigit + 1) % 2;

    if (++refreshCounter >= 20) refreshCounter = 0;
}

SSG_Error_t SSG_ShowDecimalPoint(SSG_Config_t* config, u8 show) {
    if (!config) return SSG_INVALID_CONFIG;

    u8 currentValue;
    switch (config->segmentPort) {
        case DIO_PORTA: currentValue = DIO_PINA_REG; break;
        case DIO_PORTB: currentValue = DIO_PINB_REG; break;
        case DIO_PORTC: currentValue = DIO_PINC_REG; break;
        case DIO_PORTD: currentValue = DIO_PIND_REG; break;
        default: return SSG_INVALID_PORT;
    }

    if (config->type == SSG_COMMON_CATHODE) {
        if (show) currentValue |= 0x80;
        else      currentValue &= ~0x80;
    } else {
        if (show) currentValue &= ~0x80;
        else      currentValue |= 0x80;
    }

    DIO_voidSetPortValue(config->segmentPort, currentValue);
    return SSG_OK;
}
