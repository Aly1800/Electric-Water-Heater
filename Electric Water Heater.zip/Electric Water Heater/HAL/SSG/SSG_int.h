#ifndef SSG_INT_H
#define SSG_INT_H

#include "../../Service/Std_type.h"

typedef enum {
    SSG_COMMON_CATHODE,
    SSG_COMMON_ANODE
} SSG_Type_t;

typedef struct {
    u8 segmentPort;
    u8 enablePort;
    u8 enablePin;
    SSG_Type_t type;
    u8 activeLow;  // 1 if digit enable is active LOW (transistor), 0 if active HIGH
} SSG_Config_t;

typedef enum {
    SSG_OK,
    SSG_INVALID_PORT,
    SSG_INVALID_NUMBER,
    SSG_INVALID_CONFIG,
    SSG_BLINK_ACTIVE
} SSG_Error_t;

SSG_Error_t SSG_Init(SSG_Config_t* config);
SSG_Error_t SSG_DisplayNumber(SSG_Config_t* config, u8 number);
void SSG_ClearDigit(SSG_Config_t* config);
void SSG_EnableDigit(SSG_Config_t* config);
void SSG_DisableDigit(SSG_Config_t* config);
SSG_Error_t SSG_BlinkDigit(SSG_Config_t* config, u8 state, u16 blinkPeriodMs);
SSG_Error_t SSG_DisplayTemperature(SSG_Config_t* digit1, SSG_Config_t* digit2, u8 temperature);
void SSG_MultiplexDigits(SSG_Config_t* digit1, SSG_Config_t* digit2, u8 value, u8 showDecimal);
void SSG_UpdateDisplays(void);
SSG_Error_t SSG_ShowDecimalPoint(SSG_Config_t* config, u8 show);

#endif

