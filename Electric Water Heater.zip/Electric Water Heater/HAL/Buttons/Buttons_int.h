#ifndef BUTTON_INT_H
#define BUTTON_INT_H

#include "../../Service/Std_type.h"

typedef enum {
    BUTTON_ON_OFF,
    BUTTON_UP,
    BUTTON_DOWN,
    BUTTON_MAX_TYPES
} Button_t;

typedef enum {
    BUTTON_RELEASED,
    BUTTON_PRESSED,
    BUTTON_LONG_PRESSED,
    BUTTON_DEBOUNCING
} Button_State_t;

typedef enum {
    BUTTON_OK,
    BUTTON_INVALID_TYPE,
    BUTTON_NOT_INITIALIZED,
    BUTTON_CALLBACK_NULL
} Button_Error_t;

typedef void (*ButtonCallback_t)(void);
typedef void (*ButtonLongPressCallback_t)(void);

Button_Error_t BUTTON_Init(void);
Button_State_t BUTTON_GetState(Button_t button);
u8 BUTTON_IsPressed(Button_t button);
u8 BUTTON_IsLongPressed(Button_t button);
Button_Error_t BUTTON_SetCallback(Button_t button, void (*callback)(void));
u32 GetSystemTicks(void);
void BUTTON_Update(void);

#endif
