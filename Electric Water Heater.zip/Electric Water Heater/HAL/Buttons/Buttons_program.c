#include "Buttons_int.h"
#include "../../MCAL/DIO/DIO_int.h"
#include "../../Service/bit_math.h"
#include "../../Service/reg.h"

static volatile u32 systemTicks = 0;

u32 GetSystemTicks(void) {
    return systemTicks;
}

#define DEBOUNCE_TIME_MS 50
#define LONG_PRESS_MS    2000

static u8 buttonStates[BUTTON_MAX_TYPES] = {0};
static u32 pressStartTimes[BUTTON_MAX_TYPES] = {0};
static void (*buttonCallbacks[BUTTON_MAX_TYPES])(void) = {NULL};

Button_Error_t BUTTON_Init(void) {
    DIO_voidSetPinDirection(DIO_PORTD, DIO_PIN_2, DIO_PIN_INPUT);
    DIO_voidSetPinDirection(DIO_PORTD, DIO_PIN_3, DIO_PIN_INPUT);
    DIO_voidSetPinDirection(DIO_PORTD, DIO_PIN_4, DIO_PIN_INPUT);
    DIO_voidEnablePullUp(DIO_PORTD, DIO_PIN_2);
    DIO_voidEnablePullUp(DIO_PORTD, DIO_PIN_3);
    DIO_voidEnablePullUp(DIO_PORTD, DIO_PIN_4);

    for(u8 i = 0; i < BUTTON_MAX_TYPES; i++) {
        buttonStates[i] = 0;
        pressStartTimes[i] = 0;
    }
    return BUTTON_OK;
}

Button_State_t BUTTON_GetState(Button_t button) {
    if(button >= BUTTON_MAX_TYPES) return BUTTON_RELEASED;

    static u32 lastCheckTimes[BUTTON_MAX_TYPES] = {0};
    u8 pinState = DIO_u8GetPinValue(DIO_PORTD, button + 2);
    u32 currentTime = GetSystemTicks();

    if(currentTime - lastCheckTimes[button] < DEBOUNCE_TIME_MS) {

    }
    lastCheckTimes[button] = currentTime;

    if(pinState == DIO_PIN_LOW) {
        if(!buttonStates[button]) {
            pressStartTimes[button] = currentTime;
        }
        buttonStates[button] = 1;

        if(currentTime - pressStartTimes[button] >= LONG_PRESS_MS) {
            return BUTTON_LONG_PRESSED;
        }
        return BUTTON_PRESSED;
    } else {
        static u8 releasedStates[BUTTON_MAX_TYPES] = {0};
        if(buttonStates[button] && !releasedStates[button]) {
            releasedStates[button] = 1;
            return BUTTON_PRESSED;
        }
        buttonStates[button] = 0;
        releasedStates[button] = 0;
        return BUTTON_RELEASED;
    }
}

u8 BUTTON_IsPressed(Button_t button) {
    return (BUTTON_GetState(button) == BUTTON_PRESSED);
}

u8 BUTTON_IsLongPressed(Button_t button) {
    return (BUTTON_GetState(button) == BUTTON_LONG_PRESSED);
}

Button_Error_t BUTTON_SetCallback(Button_t button, void (*callback)(void)) {
    if(button >= BUTTON_MAX_TYPES) return BUTTON_INVALID_TYPE;
    buttonCallbacks[button] = callback;
    return BUTTON_OK;
}

void __vector_X(void) __attribute__((signal));
void __vector_X(void) {
    for(u8 i = 0; i < BUTTON_MAX_TYPES; i++) {
        if(buttonCallbacks[i] && BUTTON_IsPressed(i)) {
            buttonCallbacks[i]();
        }
    }
}

void BUTTON_Update(void) {
    for(u8 i = 0; i < BUTTON_MAX_TYPES; i++) {
        Button_State_t state = BUTTON_GetState(i);
        if(buttonCallbacks[i]) {
            switch(state) {
                case BUTTON_PRESSED:
                    buttonCallbacks[i]();
                    break;
                case BUTTON_LONG_PRESSED:
                    // Optional: Add separate long-press callback if needed
                    buttonCallbacks[i]();
                    break;
                default:
                    break;
            }
        }
    }
}
