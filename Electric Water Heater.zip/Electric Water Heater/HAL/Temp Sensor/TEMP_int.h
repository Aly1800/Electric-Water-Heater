#ifndef TEMP_INT_H
#define TEMP_INT_H

#include "../../Service/Std_type.h"

typedef enum {
    TEMP_OK,
    TEMP_SENSOR_ERROR,
    TEMP_INVALID_RANGE,
    TEMP_NOT_INITIALIZED,
    TEMP_EEPROM_ERROR,
    TEMP_NULL_POINTER
} TEMP_Error_t;

#define TEMP_SENSOR_LM35    0
#define TEMP_SENSOR_DS18B20 1

void TEMP_Init(void);
TEMP_Error_t TEMP_Read(u8* temperature);
TEMP_Error_t TEMP_ReadAverage(u8* temperature);
void TEMP_SetCalibration(s8 offset);
TEMP_Error_t TEMP_ValidateRange(u8 temp);
u8 TEMP_GetSetTemperature(void);
TEMP_Error_t TEMP_SetTemperature(u8 newTemp);

#endif
