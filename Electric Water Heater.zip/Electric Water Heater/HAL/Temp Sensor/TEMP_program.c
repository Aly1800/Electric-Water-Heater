#include "TEMP_int.h"
#include "../../MCAL/ADC/ADC_int.h"
#include "../../MCAL/EEPROM/EEPROM_int.h"
#include "../../Service/bit_math.h"

#ifndef ADC_CH0
#define ADC_CH0 0
#endif

#ifndef ADC_OK
#define ADC_OK 0
#endif

#define EEPROM_TEMP_ADDR 0x00

#define NUM_SAMPLES         10
#define DEFAULT_TEMP        60
#define TEMP_OFFSET         0
#define MIN_TEMP            35
#define MAX_TEMP            75

static s8 calibrationOffset = TEMP_OFFSET;
static u8 tempSamples[NUM_SAMPLES] = {0};
static u8 sampleIndex = 0;

void TEMP_Init(void) {
    ADC_voidInit();

    for(u8 i=0; i<NUM_SAMPLES; i++)
    {
        tempSamples[i] = DEFAULT_TEMP;
    }
}

TEMP_Error_t TEMP_Read(u8* temperature) {
    if(temperature == NULL) return TEMP_SENSOR_ERROR;

    u16 adcValue = ADC_u16StartConversion(ADC_CH0);

    if(adcValue == 0xFFFF) return TEMP_SENSOR_ERROR;

    u16 rawTemp = (adcValue * 5000UL) / 1024;  // Now in 0.1�C units
    s16 calculatedTemp = (rawTemp / 10) + calibrationOffset;

    if(calculatedTemp < 0) calculatedTemp = 0;
    else if(calculatedTemp > 255) calculatedTemp = 255;

    *temperature = (u8)calculatedTemp;

    return TEMP_ValidateRange(*temperature);
}

TEMP_Error_t TEMP_ReadAverage(u8* temperature) {
    if(temperature == NULL) return TEMP_SENSOR_ERROR;

    u8 newSample;
    TEMP_Error_t status = TEMP_Read(&newSample);

    if(status != TEMP_OK) {
        newSample = tempSamples[(sampleIndex + NUM_SAMPLES - 1) % NUM_SAMPLES];
    }

    tempSamples[sampleIndex] = newSample;
    sampleIndex = (sampleIndex + 1) % NUM_SAMPLES;

    u8 min = 255, max = 0;
    u32 sum = 0;
    for(u8 i = 0; i < NUM_SAMPLES; i++) {
        sum += tempSamples[i];
        if(tempSamples[i] < min) min = tempSamples[i];
        if(tempSamples[i] > max) max = tempSamples[i];
    }

    if(NUM_SAMPLES > 2) {
        sum = sum - min - max;
        *temperature = sum / (NUM_SAMPLES - 2);
    } else {
        *temperature = sum / NUM_SAMPLES;
    }

    return TEMP_ValidateRange(*temperature);
}

void TEMP_SetCalibration(s8 offset) {
    calibrationOffset = offset;
}

TEMP_Error_t TEMP_ValidateRange(u8 temp) {
    if(temp < MIN_TEMP || temp > MAX_TEMP) {
        return TEMP_INVALID_RANGE;
    }
    return TEMP_OK;
}

u8 TEMP_GetSetTemperature(void) {
    u8 setTemp;
    EEPROM_Status_t status = IN_EEPROM_voidReadDataByte(EEPROM_TEMP_ADDR, &setTemp);

    if(status != EEPROM_OK || setTemp < MIN_TEMP || setTemp > MAX_TEMP) {
        // Reset to default if invalid
        setTemp = DEFAULT_TEMP;
        IN_EEPROM_voidWriteDataByte(EEPROM_TEMP_ADDR, setTemp);
    }

    return setTemp;
}

TEMP_Error_t TEMP_SetTemperature(u8 newTemp) {
    if(newTemp < MIN_TEMP || newTemp > MAX_TEMP) {
        return TEMP_INVALID_RANGE;
    }

    // Write to EEPROM
    EEPROM_Status_t status = IN_EEPROM_voidWriteDataByte(EEPROM_TEMP_ADDR, newTemp);
    if(status != EEPROM_OK) {
        return TEMP_EEPROM_ERROR;
    }

    // Verify write
    u8 verifyTemp;
    status = IN_EEPROM_voidReadDataByte(EEPROM_TEMP_ADDR, &verifyTemp);
    if(status != EEPROM_OK || verifyTemp != newTemp) {
        return TEMP_EEPROM_ERROR;
    }

    return TEMP_OK;
}
