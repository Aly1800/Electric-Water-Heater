#include "../MCAL/DIO/DIO_int.h"
#include "Heat_control.h"
#include "../HAL/Buttons/Buttons_int.h"
#include "../HAL/Temp Sensor/TEMP_int.h"
#include "../HAL/SSG/SSG_int.h"
#include "../HAL/Element Control/Element_int.h"
#include <util/delay.h>

#define DEFAULT_SET_TEMP         60
#define TEMP_STEP                5
#define MIN_SET_TEMP             35
#define MAX_SET_TEMP             75
#define TEMP_HYSTERESIS          2
#define TEMP_SAMPLING_INTERVAL   100
#define DISPLAY_REFRESH_RATE     20
#define SETTING_MODE_TIMEOUT     5000
#define BLINK_INTERVAL           500
#define BLANK_DISPLAY            10

static SSG_Config_t digit1Config = {
    .segmentPort = DIO_PORTC,
    .enablePort  = DIO_PORTD,
    .enablePin   = DIO_PIN_5,
    .type        = SSG_COMMON_CATHODE,
    .activeLow   = 1
};

static SSG_Config_t digit2Config = {
    .segmentPort = DIO_PORTC,
    .enablePort  = DIO_PORTD,
    .enablePin   = DIO_PIN_6,
    .type        = SSG_COMMON_CATHODE,
    .activeLow   = 1
};

typedef enum {
    BUTTON_HANDLER_IDLE,
    BUTTON_HANDLER_DEBOUNCING,
    BUTTON_HANDLER_PRESSED
} ButtonHandlerState_t;

static ButtonHandlerState_t onOffState = BUTTON_HANDLER_IDLE;
static ButtonHandlerState_t upState = BUTTON_HANDLER_IDLE;
static ButtonHandlerState_t downState = BUTTON_HANDLER_IDLE;
static u32 buttonPressTime = 0;
static System_State_t systemState = SYSTEM_OFF;
static Heater_State_t heaterState = HEATER_IDLE;
static u8 setTemperature = DEFAULT_SET_TEMP;
static u32 lastSettingModeTime = 0;
static u32 lastTempUpdate = 0;
static u32 lastDisplayUpdate = 0;
static u8 blinkState = 0;

static void UpdateTemperatureControl(void);
static void UpdateDisplay(void);
static void ExitSettingMode(void);
static u8 CalculateHeaterPwm(u8 currentTemp);
static u8 CalculateCoolerPwm(u8 currentTemp);
static void HandleSettingModeTimeout(void);

void HEATER_Init(void) {
    BUTTON_Init();
    TEMP_Init();
    ELEMENT_Init();
    SSG_Init(&digit1Config);
    SSG_Init(&digit2Config);

    setTemperature = TEMP_GetSetTemperature();

    if (setTemperature < MIN_SET_TEMP || setTemperature > MAX_SET_TEMP) {
        setTemperature = DEFAULT_SET_TEMP;
        TEMP_SetTemperature(setTemperature);  // Write clean value back to EEPROM
    }
    SSG_DisplayTemperature(&digit1Config, &digit2Config, setTemperature);
}

static u8 lastButtonStates[BUTTON_MAX_TYPES] = {1,1,1};

void HEATER_Update(void) {
    u32 currentTime = GetSystemTickCount();

    if(currentTime - lastTempUpdate >= TEMP_SAMPLING_INTERVAL) {
        lastTempUpdate = currentTime;
        UpdateTemperatureControl();
    }

    if(currentTime - lastDisplayUpdate >= DISPLAY_REFRESH_RATE) {
        lastDisplayUpdate = currentTime;
        UpdateDisplay();
        SSG_UpdateDisplays();
    }

    if(systemState == SYSTEM_SETTING_TEMP) {
        HandleSettingModeTimeout();
    }
}

static void UpdateTemperatureControl(void) {
    u8 currentTemp;
    TEMP_Error_t tempStatus = TEMP_ReadAverage(&currentTemp);

    if(tempStatus != TEMP_OK) {
        ELEMENT_ForceShutdown();
        heaterState = HEATER_ERROR;
        return;
    }

    if(systemState == SYSTEM_ON) {
        s8 tempDiff = setTemperature - currentTemp;

        if(tempDiff >= TEMP_HYSTERESIS) {
            u8 pwmValue = CalculateHeaterPwm(currentTemp);
            ELEMENT_SetPwmDuty(ELEMENT_HEATER, pwmValue);
            ELEMENT_SetState(ELEMENT_PELTIER, ELEMENT_OFF);
            heaterState = HEATER_HEATING;
        } else if(tempDiff <= -TEMP_HYSTERESIS) {
            u8 pwmValue = CalculateCoolerPwm(currentTemp);
            ELEMENT_SetPwmDuty(ELEMENT_PELTIER, pwmValue);
            ELEMENT_SetState(ELEMENT_HEATER, ELEMENT_OFF);
            heaterState = HEATER_COOLING;
        } else {
            ELEMENT_SetState(ELEMENT_HEATER, ELEMENT_OFF);
            ELEMENT_SetState(ELEMENT_PELTIER, ELEMENT_OFF);
            heaterState = HEATER_IDLE;
        }

        ELEMENT_UpdateHeaterIndicator(
            heaterState == HEATER_HEATING,
            heaterState == HEATER_COOLING
        );
    }
}

static u8 CalculateHeaterPwm(u8 currentTemp) {
    s8 difference = setTemperature - currentTemp;
    return (difference > 5) ? 255 : (u8)(difference * 51);
}

static u8 CalculateCoolerPwm(u8 currentTemp) {
    s8 difference = currentTemp - setTemperature;
    return (difference > 5) ? 255 : (u8)(difference * 51);
}

static void UpdateDisplay(void) {
    static u32 lastBlinkToggle = 0;
    u32 currentTime = GetSystemTickCount();

    switch(systemState) {
        case SYSTEM_SETTING_TEMP:
            if(currentTime - lastBlinkToggle >= BLINK_INTERVAL / 2) {
                lastBlinkToggle = currentTime;
                blinkState = !blinkState;
            }

            SSG_BlinkDigit(&digit1Config, blinkState, BLINK_INTERVAL);
            SSG_BlinkDigit(&digit2Config, blinkState, BLINK_INTERVAL);

            if(blinkState) {
                SSG_DisplayTemperature(&digit1Config, &digit2Config, setTemperature);
            } else {
                SSG_ClearDigit(&digit1Config);
                SSG_ClearDigit(&digit2Config);
            }
            break;

        case SYSTEM_ON:
        	SSG_DisplayTemperature(&digit1Config, &digit2Config, HEATER_GetCurrentTemp());
            break;

        case SYSTEM_OFF:
            SSG_ClearDigit(&digit1Config);
            SSG_ClearDigit(&digit2Config);
            break;
    }
}

static void HandleSettingModeTimeout(void) {
    if(GetSystemTickCount() - lastSettingModeTime >= SETTING_MODE_TIMEOUT) {
        ExitSettingMode();
    }
}

static void ExitSettingMode(void) {
    systemState = SYSTEM_ON;
    blinkState = 0;
    SSG_BlinkDigit(&digit1Config, 0, BLINK_INTERVAL);
    SSG_BlinkDigit(&digit2Config, 0, BLINK_INTERVAL);
}

void HEATER_SetPowerState(u8 state) {
    if(state) {
        systemState = SYSTEM_ON;
        ELEMENT_EnableSafetyLock(0);
    } else {
        systemState = SYSTEM_OFF;
        ELEMENT_ForceShutdown();
        ELEMENT_EnableSafetyLock(1);
    }
}

u8 HEATER_GetCurrentTemp(void) {
    u8 temp = 0;
    if (TEMP_ReadAverage(&temp) != TEMP_OK) {
        return 0xFF;  // or another out-of-range value to indicate error
    }
    return temp;
}

u8 HEATER_GetSetTemp(void) {
    return setTemperature;
}

System_State_t HEATER_GetSystemState(void) {
    return systemState;
}

void HEATER_HandleOnOffButton(void) {
    switch(onOffState) {
        case BUTTON_HANDLER_IDLE:
            if(BUTTON_IsPressed(BUTTON_ON_OFF)) {
                buttonPressTime = GetSystemTickCount();
                onOffState = BUTTON_DEBOUNCING;
            }
            break;

        case BUTTON_HANDLER_DEBOUNCING:
            if(GetSystemTickCount() - buttonPressTime > 50) {
                if(BUTTON_IsPressed(BUTTON_ON_OFF)) {
                    onOffState = BUTTON_PRESSED;
                    HEATER_SetPowerState(systemState == SYSTEM_OFF);
                    SSG_DisplayTemperature(&digit1Config, &digit2Config, 10); // Blank display
                } else {
                    onOffState = BUTTON_HANDLER_IDLE;
                }
            }
            break;

        case BUTTON_HANDLER_PRESSED:
            if(!BUTTON_IsPressed(BUTTON_ON_OFF)) {
                onOffState = BUTTON_HANDLER_IDLE;
            }
            break;
    }
}

void HEATER_HandleUpButton(void) {
    if(BUTTON_IsPressed(BUTTON_UP)) {
        _delay_ms(50);
        if(systemState == SYSTEM_OFF) return;

        if(systemState != SYSTEM_SETTING_TEMP) {
            systemState = SYSTEM_SETTING_TEMP;
            lastSettingModeTime = GetSystemTickCount();
        }

        if(setTemperature <= (MAX_SET_TEMP - TEMP_STEP))
            setTemperature += TEMP_STEP;
        else
            setTemperature = MAX_SET_TEMP;

        TEMP_SetTemperature(setTemperature);
        lastSettingModeTime = GetSystemTickCount();

        while(BUTTON_IsPressed(BUTTON_UP));
        _delay_ms(200);
    }
}

void HEATER_HandleDownButton(void) {
    if(BUTTON_IsPressed(BUTTON_DOWN)) {
        _delay_ms(50);
        if(systemState == SYSTEM_OFF) return;

        if(systemState != SYSTEM_SETTING_TEMP) {
            systemState = SYSTEM_SETTING_TEMP;
            lastSettingModeTime = GetSystemTickCount();
        }

        if(setTemperature >= (MIN_SET_TEMP + TEMP_STEP))
            setTemperature -= TEMP_STEP;
        else
            setTemperature = MIN_SET_TEMP;

        TEMP_SetTemperature(setTemperature);
        lastSettingModeTime = GetSystemTickCount();

        while(BUTTON_IsPressed(BUTTON_DOWN));
        _delay_ms(200);
    }
}
