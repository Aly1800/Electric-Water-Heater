#ifndef HEATER_CONTROL_H
#define HEATER_CONTROL_H

#include "../Service/Std_type.h"

typedef enum {
    SYSTEM_OFF,
    SYSTEM_ON,
    SYSTEM_SETTING_TEMP
} System_State_t;

typedef enum {
    HEATER_IDLE,
    HEATER_HEATING,
    HEATER_COOLING,
    HEATER_ERROR
} Heater_State_t;

void HEATER_Init(void);
void HEATER_Update(void);
void HEATER_SetPowerState(u8 state);
u8 HEATER_GetCurrentTemp(void);
u8 HEATER_GetSetTemp(void);
System_State_t HEATER_GetSystemState(void);
void HEATER_HandleOnOffButton(void);
void HEATER_HandleUpButton(void);
void HEATER_HandleDownButton(void);

#endif
