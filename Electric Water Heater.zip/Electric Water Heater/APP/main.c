#include "../Service/Std_type.h"
#include "../Service/bit_math.h"
#include "../Service/reg.h"
#include "../MCAL/DIO/DIO_int.h"
#include "../MCAL/ADC/ADC_int.h"
#include "../MCAL/TIMER0/TIMER0_int.h"
#include "../MCAL/TIMER0/TIMER0_cfg.h"
#include "../HAL/Buttons/Buttons_int.h"
#include "../HAL/Temp Sensor/TEMP_int.h"
#include "../HAL/SSG/SSG_int.h"
#include "../HAL/Element Control/Element_int.h"
#include "Heat_control.h"
#include <avr/interrupt.h>
#include <util/delay.h>

#define GIE_voidEnable()  SET_BIT(SREG, 7)


u32 GetSystemTickCount(void) {
    return systemTickCount;
}

void System_Init(void) {
    DIO_voidInit();
    ADC_voidInit();
    TIMER0_voidInit();
    TIMER0_voidSet_OV_CallBack(BUTTON_Update);
    TIMER0_voidSet_OV_CallBack(SSG_UpdateDisplays);
    TIMER0_voidSet_OV_CallBack(ELEMENT_Update);
    TIMER0_voidSetPreLoadVal(6);
    GIE_voidEnable();
    HEATER_Init();
}

int main(void) {
    System_Init();
    while(1) {
        HEATER_HandleOnOffButton();
        HEATER_HandleUpButton();
        HEATER_HandleDownButton();
        HEATER_Update();
        ELEMENT_Update();

        asm("SLEEP");
    }
    return 0;
}


